package com.museum.system.Services;

import com.museum.system.Entities.Event;

import java.util.List;
import java.util.Optional;

public interface IEventService {
    public Event createEvent(Event event) ;

    public Optional<Event> getEventById(Long id) ;

    public List<Event> getAllEvents() ;

    public Event updateEvent(Long id, Event eventDetails) ;

    public void deleteEvent(Long id) ;
}
