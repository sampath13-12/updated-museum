package com.museum.system.Entities;

public enum Role {
    GENERAL_PUBLIC,
    INSURANCE_SECURITY,
    BUSINESS_PARTNER,
    EMPLOYEE
}
