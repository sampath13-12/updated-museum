package com.museum.system.Services;

import com.museum.system.Entities.DisplayArea;

import java.util.List;
import java.util.Optional;

public interface IDisplayAreaService {

    public DisplayArea createDisplayArea(DisplayArea displayArea) ;

    public Optional<DisplayArea> getDisplayAreaById(Long id) ;

    public List<DisplayArea> getAllDisplayAreas() ;

    public DisplayArea updateDisplayArea(Long id, DisplayArea displayDetails) ;

    public void deleteDisplayArea(Long id) ;

}
