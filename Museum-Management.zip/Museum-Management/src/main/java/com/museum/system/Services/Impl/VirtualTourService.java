package com.museum.system.Services.Impl;

import com.museum.system.Entities.VirtualTour;
import com.museum.system.Repositories.IVirtualTourRepository;
import com.museum.system.Services.IVirtualTourService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VirtualTourService implements IVirtualTourService {

    @Autowired
    private IVirtualTourRepository virtualTourRepository;

    @Override
    public VirtualTour createVirtualTour(VirtualTour virtualTour) {
        return virtualTourRepository.save(virtualTour);
    }

    @Override
    public Optional<VirtualTour> getVirtualTourById(Long id) {
        return virtualTourRepository.findById(id);
    }

    @Override
    public List<VirtualTour> getAllVirtualTours() {
        return virtualTourRepository.findAll();
    }

    @Override
    public VirtualTour updateVirtualTour(Long id, VirtualTour virtualTourDetails) {
        try {
            VirtualTour virtualTour = getVirtualTourById(id).orElseThrow(() ->
                    new IllegalArgumentException("VirtualTour not found with id: " + id)
            );
            virtualTour.setTheme(virtualTourDetails.getTheme());
            virtualTour.setObjectsIncluded(virtualTourDetails.getObjectsIncluded());
            virtualTour.setRenderingsType(virtualTourDetails.getRenderingsType());
            virtualTour.setLanguage(virtualTourDetails.getLanguage());
            virtualTour.setContractType(virtualTourDetails.getContractType());
            return virtualTourRepository.save(virtualTour);
        } catch (IllegalArgumentException e) {
            System.err.println("Error updating VirtualTour: " + e.getMessage());
            return null;
        }
    }

    @Override
    public void deleteVirtualTour(Long id) {
        Optional<VirtualTour> virtualTour = getVirtualTourById(id);
        virtualTourRepository.delete(virtualTour);
    }
}
