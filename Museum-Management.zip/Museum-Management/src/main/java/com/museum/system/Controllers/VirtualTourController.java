package com.museum.system.Controllers;

import com.museum.system.Entities.VirtualTour;
import com.museum.system.Services.Impl.VirtualTourService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/virtual-tours")
public class VirtualTourController {

    @Autowired
    private VirtualTourService virtualTourService;

    // Create a new Virtual Tour
    @PostMapping
    public ResponseEntity<VirtualTour> createVirtualTour(@Valid @RequestBody VirtualTour virtualTour) {
        VirtualTour createdTour = virtualTourService.createVirtualTour(virtualTour);
        return new ResponseEntity<>(createdTour, HttpStatus.CREATED);
    }

    // Get a Virtual Tour by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<VirtualTour>> getVirtualTourById(@PathVariable Long id) {
        Optional<VirtualTour> virtualTour = virtualTourService.getVirtualTourById(id);
        return new ResponseEntity<>(virtualTour, HttpStatus.OK);
    }

    // Get all Virtual Tours
    @GetMapping
    public ResponseEntity<List<VirtualTour>> getAllVirtualTours() {
        List<VirtualTour> tours = virtualTourService.getAllVirtualTours();
        return new ResponseEntity<>(tours, HttpStatus.OK);
    }

    // Update a Virtual Tour
    @PutMapping("/{id}")
    public ResponseEntity<VirtualTour> updateVirtualTour(@PathVariable Long id, @Valid @RequestBody VirtualTour virtualTourDetails) {
        VirtualTour updatedTour = virtualTourService.updateVirtualTour(id, virtualTourDetails);
        return new ResponseEntity<>(updatedTour, HttpStatus.OK);
    }

    // Delete a Virtual Tour
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVirtualTour(@PathVariable Long id) {
        virtualTourService.deleteVirtualTour(id);
        return ResponseEntity.noContent().build();
    }

    // Additional endpoints as required
}
