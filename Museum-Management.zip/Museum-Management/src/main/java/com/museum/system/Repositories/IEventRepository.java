package com.museum.system.Repositories;

import com.museum.system.Entities.Event;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IEventRepository extends JpaRepository<Event, Long> {
    void delete(Optional<Event> event);
}
