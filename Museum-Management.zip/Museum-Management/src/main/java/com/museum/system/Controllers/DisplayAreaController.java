package com.museum.system.Controllers;

import com.museum.system.Entities.DisplayArea;
import com.museum.system.Services.Impl.DisplayAreaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/display-areas")
public class DisplayAreaController {

    @Autowired
    private DisplayAreaService displayAreaService;

    // Create a new Display Area
    @PostMapping
    public ResponseEntity<DisplayArea> createDisplayArea(@Valid @RequestBody DisplayArea displayArea) {
        DisplayArea createdArea = displayAreaService.createDisplayArea(displayArea);
        return new ResponseEntity<>(createdArea, HttpStatus.CREATED);
    }

    // Get a Display Area by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<DisplayArea>> getDisplayAreaById(@PathVariable Long id) {
        Optional<DisplayArea> displayArea = displayAreaService.getDisplayAreaById(id);
        return new ResponseEntity<>(displayArea, HttpStatus.OK);
    }

    // Get all Display Areas
    @GetMapping
    public ResponseEntity<List<DisplayArea>> getAllDisplayAreas() {
        List<DisplayArea> areas = displayAreaService.getAllDisplayAreas();
        return new ResponseEntity<>(areas, HttpStatus.OK);
    }

    // Update a Display Area
    @PutMapping("/{id}")
    public ResponseEntity<DisplayArea> updateDisplayArea(@PathVariable Long id, @Valid @RequestBody DisplayArea displayDetails) {
        DisplayArea updatedArea = displayAreaService.updateDisplayArea(id, displayDetails);
        return new ResponseEntity<>(updatedArea, HttpStatus.OK);
    }

    // Delete a Display Area
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDisplayArea(@PathVariable Long id) {
        displayAreaService.deleteDisplayArea(id);
        return ResponseEntity.noContent().build();
    }

    // Additional endpoints as required
}