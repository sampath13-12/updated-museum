package com.museum.system.Controllers;

import com.museum.system.Entities.ArtObject;
import com.museum.system.Services.Impl.ArtObjectService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/artobjects")
public class ArtObjectController {

    @Autowired
    private ArtObjectService artObjectService;

    // Create a new Art Object
    @PostMapping
    public ResponseEntity<ArtObject> createArtObject(@Valid @RequestBody ArtObject artObject) {
        ArtObject createdArtObject = artObjectService.createArtObject(artObject);
        return new ResponseEntity<>(createdArtObject, HttpStatus.CREATED);
    }

    // Get an Art Object by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<ArtObject>> getArtObjectById(@PathVariable Long id) {
        Optional<ArtObject> artObject = artObjectService.getArtObjectById(id);
        return new ResponseEntity<>(artObject, HttpStatus.OK);
    }

    // Get all Art Objects
    @GetMapping
    public ResponseEntity<List<ArtObject>> getAllArtObjects() {
        List<ArtObject> artObjects = artObjectService.getAllArtObjects();
        return new ResponseEntity<>(artObjects, HttpStatus.OK);
    }

    // Update an Art Object
    @PutMapping("/{id}")
    public ResponseEntity<ArtObject> updateArtObject(@PathVariable Long id, @Valid @RequestBody ArtObject artObjectDetails) {
        ArtObject updatedArtObject = artObjectService.updateArtObject(id, artObjectDetails);
        return new ResponseEntity<>(updatedArtObject, HttpStatus.OK);
    }

    // Delete an Art Object
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArtObject(@PathVariable Long id) {
        artObjectService.deleteArtObject(id);
        return ResponseEntity.noContent().build();
    }

}
