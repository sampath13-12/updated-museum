package com.museum.system.Security;

public class WebSecurityConfigurerAdapter {
}
