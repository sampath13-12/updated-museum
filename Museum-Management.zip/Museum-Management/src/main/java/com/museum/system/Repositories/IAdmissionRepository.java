package com.museum.system.Repositories;

import com.museum.system.Entities.Admission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IAdmissionRepository extends JpaRepository<Admission, Long> {
    void delete(Optional<Admission> admission);
}
