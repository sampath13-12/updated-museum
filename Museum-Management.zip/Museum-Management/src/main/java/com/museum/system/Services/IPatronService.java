package com.museum.system.Services;

import com.museum.system.Entities.Patron;

import java.util.List;
import java.util.Optional;

public interface IPatronService {

    public Patron createPatron(Patron patron) ;

    public Optional<Patron> getPatronById(Long id) ;

    public List<Patron> getAllPatrons() ;

    public Patron updatePatron(Long id, Patron patronDetails) ;

    public void deletePatron(Long id) ;
}
