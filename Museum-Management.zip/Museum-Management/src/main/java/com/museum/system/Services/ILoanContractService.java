package com.museum.system.Services;

import com.museum.system.Entities.LoanContract;

import java.util.List;
import java.util.Optional;

public interface ILoanContractService {

    public LoanContract createLoanContract(LoanContract loanContract) ;

    public Optional<LoanContract> getLoanContractById(Long id) ;

    public List<LoanContract> getAllLoanContracts() ;

    public LoanContract updateLoanContract(Long id, LoanContract loanDetails) ;

    public boolean deleteLoanContract(Long id) ;
}
