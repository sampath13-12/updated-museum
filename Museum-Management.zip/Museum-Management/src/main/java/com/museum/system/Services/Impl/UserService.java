package com.museum.system.Services.Impl;

import com.museum.system.Entities.User;
import com.museum.system.Repositories.IUserRepository;
import com.museum.system.Services.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class UserService implements IUserService {

    @Autowired
    private IUserRepository userRepository;

    // For Spring Security authentication
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
                getAuthority(user));
    }

    private List<Object> getAuthority(User user) {
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));
    }

    public User save(User user) {
        return userRepository.save(user);
    }

    public Optional<Object> findByUsername(String username) {
    }


    ///
    ///
    ///
    /// NEED TO CHANGE USER SERVICE CLASS.......................
    ///
    ///
    ///
    ///
    ///
    ///

}
