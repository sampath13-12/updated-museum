package com.museum.system.Services.Impl;

import com.museum.system.Entities.AcquisitionRecord;
import com.museum.system.Repositories.IAcquisitionRecordRepository;
import com.museum.system.Services.IAcquisitionRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AcquisitionRecordService implements IAcquisitionRecordService {

    @Autowired
    private IAcquisitionRecordRepository acquisitionRecordRepository;


    @Override
    public AcquisitionRecord createAcquisitionRecord(AcquisitionRecord acquisitionRecord) {
        return acquisitionRecordRepository.save(acquisitionRecord);
    }

    @Override
    public Optional<AcquisitionRecord> getAcquisitionRecordById(Long id) {
        return acquisitionRecordRepository.findById(id);
    }

    @Override
    public List<AcquisitionRecord> getAllAcquisitionRecords() {
        return acquisitionRecordRepository.findAll();
    }

    @Override
    public AcquisitionRecord updateAcquisitionRecord(Long id, AcquisitionRecord acquisitionDetails) {
        Optional<AcquisitionRecord> existingAcquisitionRecord = acquisitionRecordRepository.findById(id);
        if(existingAcquisitionRecord.isPresent()){
            AcquisitionRecord toUpdateAcquisitionRecord = existingAcquisitionRecord.get();
            toUpdateAcquisitionRecord.setAcquisitionDate(acquisitionDetails.getAcquisitionDate());
            toUpdateAcquisitionRecord.setPrice(acquisitionDetails.getPrice());
            toUpdateAcquisitionRecord.setPlaceOfPurchase(acquisitionDetails.getPlaceOfPurchase());
            toUpdateAcquisitionRecord.setDonorInfo(acquisitionDetails.getDonorInfo());
        }
        return acquisitionRecordRepository.save(acquisitionDetails);
    }

    @Override
    public boolean deleteAcquisitionRecord(Long id) {
        Optional<AcquisitionRecord> acquisitionRecord = getAcquisitionRecordById(id);
        if(acquisitionRecord.isPresent()){
            acquisitionRecordRepository.delete(acquisitionRecord);
            return true;
        }
        return false;
    }
}
