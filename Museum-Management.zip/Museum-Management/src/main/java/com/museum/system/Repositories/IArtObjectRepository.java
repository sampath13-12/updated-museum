package com.museum.system.Repositories;

import com.museum.system.Entities.ArtObject;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface IArtObjectRepository extends JpaRepository<ArtObject, Long> {

    void delete(Optional<ArtObject> artObject);
}
