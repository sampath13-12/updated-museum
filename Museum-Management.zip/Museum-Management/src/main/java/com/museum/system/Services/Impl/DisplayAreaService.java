package com.museum.system.Services.Impl;

import com.museum.system.Entities.DisplayArea;
import com.museum.system.Repositories.IDisplayAreaRepository;
import com.museum.system.Services.IDisplayAreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class DisplayAreaService implements IDisplayAreaService {

    @Autowired
    private IDisplayAreaRepository displayAreaRepository;

    @Override
    public DisplayArea createDisplayArea(DisplayArea displayArea) {
        return displayAreaRepository.save(displayArea);
    }

    @Override
    public Optional<DisplayArea> getDisplayAreaById(Long id) {
        return displayAreaRepository.findById(id);
    }

    @Override
    public List<DisplayArea> getAllDisplayAreas() {
        return displayAreaRepository.findAll();
    }

    @Override
    public DisplayArea updateDisplayArea(Long id, DisplayArea displayDetails) {
        Optional<DisplayArea> displayArea = displayAreaRepository.findById(id);
        if(displayArea.isPresent()){
            displayArea.get().setName(displayDetails.getName());
            displayArea.get().setType(displayDetails.getType());
            displayArea.get().setSecurityLevel(displayDetails.getSecurityLevel());
            displayArea.get().setSubAreas(displayDetails.getSubAreas());
            displayArea.get().setParentDisplayArea(displayDetails.getParentDisplayArea());
        }
        return displayAreaRepository.save(displayDetails);
    }

    @Override
    public void deleteDisplayArea(Long id) {
        Optional<DisplayArea> displayArea = displayAreaRepository.findById(id);
        if(displayArea.isPresent()){
            displayAreaRepository.delete(displayArea);
        }
    }
}
