package com.museum.system.Controllers;


import com.museum.system.Entities.LoanContract;
import com.museum.system.Services.Impl.LoanContractService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/loans")
public class LoanContractController {

    @Autowired
    private LoanContractService loanContractService;

    // Create a new Loan Contract
    @PostMapping
    public ResponseEntity<LoanContract> createLoanContract(@Valid @RequestBody LoanContract loanContract) {
        LoanContract createdLoan = loanContractService.createLoanContract(loanContract);
        return new ResponseEntity<>(createdLoan, HttpStatus.CREATED);
    }

    // Get a Loan Contract by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<LoanContract>> getLoanContractById(@PathVariable Long id) {
        Optional<LoanContract> loanContract = loanContractService.getLoanContractById(id);
        return new ResponseEntity<>(loanContract, HttpStatus.OK);
    }

    // Get all Loan Contracts
    @GetMapping
    public ResponseEntity<List<LoanContract>> getAllLoanContracts() {
        List<LoanContract> loans = loanContractService.getAllLoanContracts();
        return new ResponseEntity<>(loans, HttpStatus.OK);
    }

    // Update a Loan Contract
    @PutMapping("/{id}")
    public ResponseEntity<LoanContract> updateLoanContract(@PathVariable Long id, @Valid @RequestBody LoanContract loanDetails) {
        LoanContract updatedLoan = loanContractService.updateLoanContract(id, loanDetails);
        return new ResponseEntity<>(updatedLoan, HttpStatus.OK);
    }

    // Delete a Loan Contract
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLoanContract(@PathVariable Long id) {
        loanContractService.deleteLoanContract(id);
        return ResponseEntity.noContent().build();
    }

    // Additional endpoints as required
}