package com.museum.system.Entities;

public enum DisposalMethod {
    DAMAGED_DESTROYED,
    SOLD,
    DONATED
}
