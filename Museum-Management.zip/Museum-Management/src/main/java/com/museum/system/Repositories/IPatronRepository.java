package com.museum.system.Repositories;

import com.museum.system.Entities.Patron;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IPatronRepository extends JpaRepository<Patron, Long> {
    void delete(Optional<Patron> patron);
}
