package com.museum.system.Services.Impl;

import com.museum.system.Entities.DisposalRecord;
import com.museum.system.Repositories.IDisposalRecordRepository;
import com.museum.system.Services.IDisposalRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DisposalRecordService implements IDisposalRecordService {

    @Autowired
    private IDisposalRecordRepository disposalRecordRepository;


    @Override
    public DisposalRecord createDisposalRecord(DisposalRecord disposalRecord) {
        return disposalRecordRepository.save(disposalRecord);
    }

    @Override
    public Optional<DisposalRecord> getDisposalRecordById(Long id) {
        return disposalRecordRepository.findById(id);
    }

    @Override
    public List<DisposalRecord> getAllDisposalRecords() {
        return disposalRecordRepository.findAll();
    }

    @Override
    public DisposalRecord updateDisposalRecord(Long id, DisposalRecord disposalDetails) {
        Optional<DisposalRecord> existingDisposalRecord = disposalRecordRepository.findById(id);
        if(existingDisposalRecord.isPresent()){
            existingDisposalRecord.get().setDisposalDate(disposalDetails.getDisposalDate());
            existingDisposalRecord.get().setDisposalMethod(disposalDetails.getDisposalMethod());
            existingDisposalRecord.get().setDisposalDetails(disposalDetails.getDisposalDetails());
        }
       return disposalRecordRepository.save(disposalDetails);
    }

    @Override
    public boolean deleteDisposalRecord(Long id) {
        Optional<DisposalRecord> disposalRecord = disposalRecordRepository.findById(id);
        if(disposalRecord.isPresent()){
            disposalRecordRepository.delete(disposalRecord);
            return true;
        }
        return false;
    }
}
