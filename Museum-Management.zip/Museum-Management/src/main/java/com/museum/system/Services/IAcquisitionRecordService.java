package com.museum.system.Services;

import com.museum.system.Entities.AcquisitionRecord;

import java.util.List;
import java.util.Optional;

public interface IAcquisitionRecordService {

    public AcquisitionRecord createAcquisitionRecord(AcquisitionRecord acquisitionRecord) ;

    public Optional<AcquisitionRecord> getAcquisitionRecordById(Long id) ;

    public List<AcquisitionRecord> getAllAcquisitionRecords() ;

    public AcquisitionRecord updateAcquisitionRecord(Long id, AcquisitionRecord acquisitionDetails) ;

    public boolean deleteAcquisitionRecord(Long id) ;
}
