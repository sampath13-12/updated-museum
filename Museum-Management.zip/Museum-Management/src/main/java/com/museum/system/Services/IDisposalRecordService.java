package com.museum.system.Services;

import com.museum.system.Entities.DisposalRecord;

import java.util.List;
import java.util.Optional;

public interface IDisposalRecordService {
    public DisposalRecord createDisposalRecord(DisposalRecord disposalRecord) ;

    public Optional<DisposalRecord> getDisposalRecordById(Long id) ;

    public List<DisposalRecord> getAllDisposalRecords() ;

    public DisposalRecord updateDisposalRecord(Long id, DisposalRecord disposalDetails) ;

    public boolean deleteDisposalRecord(Long id) ;
}
