package com.museum.system.Services.Impl;

import com.museum.system.Entities.Patron;
import com.museum.system.Repositories.IPatronRepository;
import com.museum.system.Services.IPatronService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatronService implements IPatronService {

    @Autowired
    private IPatronRepository patronRepository;


    @Override
    public Patron createPatron(Patron patron) {
        return patronRepository.save(patron);
    }

    @Override
    public Optional<Patron> getPatronById(Long id) {
        return patronRepository.findById(id);
    }

    @Override
    public List<Patron> getAllPatrons() {
        return patronRepository.findAll();
    }

    @Override
    public Patron updatePatron(Long id, Patron patronDetails) {
        try {
            Patron patron = getPatronById(id).orElseThrow(() ->
                    new IllegalArgumentException("Patron not found with id: " + id)
            );
            patron.setName(patronDetails.getName());
            patron.setContactInfo(patronDetails.getContactInfo());
            patron.setPatronType(patronDetails.getPatronType());
            return patronRepository.save(patron);    } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }

    }

    @Override
    public void deletePatron(Long id) {
        Optional<Patron> patron = getPatronById(id);
        patronRepository.delete(patron);
    }
}
