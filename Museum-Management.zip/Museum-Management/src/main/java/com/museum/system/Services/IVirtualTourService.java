package com.museum.system.Services;

import com.museum.system.Entities.VirtualTour;

import java.util.List;
import java.util.Optional;

public interface IVirtualTourService {

    public VirtualTour createVirtualTour(VirtualTour virtualTour) ;

    public Optional<VirtualTour> getVirtualTourById(Long id) ;

    public List<VirtualTour> getAllVirtualTours() ;

    public VirtualTour updateVirtualTour(Long id, VirtualTour virtualTourDetails) ;

    public void deleteVirtualTour(Long id) ;
}
