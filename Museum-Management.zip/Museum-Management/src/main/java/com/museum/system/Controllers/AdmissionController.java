package com.museum.system.Controllers;


import com.museum.system.Entities.Admission;
import com.museum.system.Services.Impl.AdmissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/admissions")
public class AdmissionController {

    @Autowired
    private AdmissionService admissionService;

    // Create a new Admission
    @PostMapping
    public ResponseEntity<Admission> createAdmission(@Valid @RequestBody Admission admission) {
        Admission createdAdmission = admissionService.createAdmission(admission);
        return new ResponseEntity<>(createdAdmission, HttpStatus.CREATED);
    }

    // Get an Admission by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<Admission>> getAdmissionById(@PathVariable Long id) {
        Optional<Admission> admission = admissionService.getAdmissionById(id);
        return new ResponseEntity<>(admission, HttpStatus.OK);
    }

    // Get all Admissions
    @GetMapping
    public ResponseEntity<List<Admission>> getAllAdmissions() {
        List<Admission> admissions = admissionService.getAllAdmissions();
        return new ResponseEntity<>(admissions, HttpStatus.OK);
    }

    // Update an Admission
    @PutMapping("/{id}")
    public ResponseEntity<Admission> updateAdmission(@PathVariable Long id, @Valid @RequestBody Admission admissionDetails) {
        Admission updatedAdmission = admissionService.updateAdmission(id, admissionDetails);
        return new ResponseEntity<>(updatedAdmission, HttpStatus.OK);
    }

    // Delete an Admission
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAdmission(@PathVariable Long id) {
        admissionService.deleteAdmission(id);
        return ResponseEntity.noContent().build();
    }

    // Additional endpoints as required
}