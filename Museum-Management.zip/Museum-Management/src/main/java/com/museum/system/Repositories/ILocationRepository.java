package com.museum.system.Repositories;

import com.museum.system.Entities.Location;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ILocationRepository extends JpaRepository<Location, Long> {
    void delete(Optional<Location> location);
}
