package com.museum.system.Repositories;

import com.museum.system.Entities.VirtualTour;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IVirtualTourRepository extends JpaRepository<VirtualTour, Long> {
    void delete(Optional<VirtualTour> virtualTour);
}
