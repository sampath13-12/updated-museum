package com.museum.system.Services.Impl;

import com.museum.system.Entities.RestorationLog;
import com.museum.system.Repositories.IRestorationLogRepository;
import com.museum.system.Services.IRestorationLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RestorationLogService implements IRestorationLogService {

    @Autowired
    private IRestorationLogRepository restorationLogRepository;


    @Override
    public RestorationLog createRestorationLog(RestorationLog restorationLog) {
        return restorationLogRepository.save(restorationLog);
    }

    @Override
    public Optional<RestorationLog> getRestorationLogById(Long id) {
        return restorationLogRepository.findById(id);
    }

    @Override
    public List<RestorationLog> getAllRestorationLogs() {
        return restorationLogRepository.findAll();
    }

    @Override
    public RestorationLog updateRestorationLog(Long id, RestorationLog restorationDetails) {
        Optional<RestorationLog> restorationLog = restorationLogRepository.findById(id);
        if(restorationLog.isPresent()){
            restorationLog.get().setArtObject(restorationDetails.getArtObject());
            restorationLog.get().setInspectionDate(restorationDetails.getInspectionDate());
            restorationLog.get().setConservationDetails(restorationDetails.getConservationDetails());
            restorationLog.get().setRestorationDetails(restorationDetails.getRestorationDetails());
        }
        return restorationLogRepository.save(restorationDetails);
    }

    @Override
    public void deleteRestorationLog(Long id) {
        Optional<RestorationLog> restorationLog = getRestorationLogById(id);
        restorationLogRepository.delete(restorationLog);
    }
}
