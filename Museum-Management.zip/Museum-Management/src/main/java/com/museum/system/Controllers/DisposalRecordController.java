package com.museum.system.Controllers;



import com.museum.system.Entities.DisposalRecord;
import com.museum.system.Services.Impl.DisposalRecordService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/disposals")
public class DisposalRecordController {

    @Autowired
    private DisposalRecordService disposalRecordService;

    // Create a new Disposal Record
    @PostMapping
    public ResponseEntity<DisposalRecord> createDisposalRecord(@Valid @RequestBody DisposalRecord disposalRecord) {
        DisposalRecord createdRecord = disposalRecordService.createDisposalRecord(disposalRecord);
        return new ResponseEntity<>(createdRecord, HttpStatus.CREATED);
    }

    // Get a Disposal Record by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<DisposalRecord>> getDisposalRecordById(@PathVariable Long id) {
        Optional<DisposalRecord> record = disposalRecordService.getDisposalRecordById(id);
        return new ResponseEntity<>(record, HttpStatus.OK);
    }

    // Get all Disposal Records
    @GetMapping
    public ResponseEntity<List<DisposalRecord>> getAllDisposalRecords() {
        List<DisposalRecord> records = disposalRecordService.getAllDisposalRecords();
        return new ResponseEntity<>(records, HttpStatus.OK);
    }

    // Update a Disposal Record
    @PutMapping("/{id}")
    public ResponseEntity<DisposalRecord> updateDisposalRecord(@PathVariable Long id, @Valid @RequestBody DisposalRecord disposalDetails) {
        DisposalRecord updatedRecord = disposalRecordService.updateDisposalRecord(id, disposalDetails);
        return new ResponseEntity<>(updatedRecord, HttpStatus.OK);
    }

    // Delete a Disposal Record
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDisposalRecord(@PathVariable Long id) {
        disposalRecordService.deleteDisposalRecord(id);
        return ResponseEntity.noContent().build();
    }

    // Additional endpoints as required
}