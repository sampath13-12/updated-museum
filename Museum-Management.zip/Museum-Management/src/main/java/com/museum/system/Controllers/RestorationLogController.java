package com.museum.system.Controllers;

import com.museum.system.Entities.RestorationLog;
import com.museum.system.Services.Impl.RestorationLogService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/restorations")
public class RestorationLogController {

    @Autowired
    private RestorationLogService restorationLogService;

    // Create a new Restoration Log
    @PostMapping
    public ResponseEntity<RestorationLog> createRestorationLog(@Valid @RequestBody RestorationLog restorationLog) {
        RestorationLog createdLog = restorationLogService.createRestorationLog(restorationLog);
        return new ResponseEntity<>(createdLog, HttpStatus.CREATED);
    }

    // Get a Restoration Log by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<RestorationLog>> getRestorationLogById(@PathVariable Long id) {
        Optional<RestorationLog> restorationLog = restorationLogService.getRestorationLogById(id);
        return new ResponseEntity<>(restorationLog, HttpStatus.OK);
    }

    // Get all Restoration Logs
    @GetMapping
    public ResponseEntity<List<RestorationLog>> getAllRestorationLogs() {
        List<RestorationLog> logs = restorationLogService.getAllRestorationLogs();
        return new ResponseEntity<>(logs, HttpStatus.OK);
    }

    // Update a Restoration Log
    @PutMapping("/{id}")
    public ResponseEntity<RestorationLog> updateRestorationLog(@PathVariable Long id, @Valid @RequestBody RestorationLog restorationDetails) {
        RestorationLog updatedLog = restorationLogService.updateRestorationLog(id, restorationDetails);
        return new ResponseEntity<>(updatedLog, HttpStatus.OK);
    }

    // Delete a Restoration Log
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRestorationLog(@PathVariable Long id) {
        restorationLogService.deleteRestorationLog(id);
        return ResponseEntity.noContent().build();
    }

    // Additional endpoints as required
}