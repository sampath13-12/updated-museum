package com.museum.system.Services.Impl;

import com.museum.system.Entities.Admission;
import com.museum.system.Repositories.IAdmissionRepository;
import com.museum.system.Services.IAdmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdmissionService implements IAdmissionService {

    @Autowired
    private IAdmissionRepository admissionRepository;


    @Override
    public Admission createAdmission(Admission admission) {
        return admissionRepository.save(admission);
    }

    @Override
    public Optional<Admission> getAdmissionById(Long id) {
        return admissionRepository.findById(id);
    }

    @Override
    public List<Admission> getAllAdmissions() {
        return admissionRepository.findAll();
    }

    @Override
    public Admission updateAdmission(Long id, Admission admissionDetails) {
        try {
            Optional<Admission> optionalAdmission = getAdmissionById(id);
            if (optionalAdmission.isPresent()) {
                Admission existingAdmission = optionalAdmission.get();
                existingAdmission.setTicketType(admissionDetails.getTicketType());
                existingAdmission.setSaleDate(admissionDetails.getSaleDate());
                existingAdmission.setPatron(admissionDetails.getPatron());
                return admissionRepository.save(existingAdmission);
            } else {
                throw new IllegalArgumentException("Admission not found with id: " + id);
            }
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            return null;
        }
    }

    @Override
    public void deleteAdmission(Long id) {
        Optional<Admission> admission = getAdmissionById(id);
        admissionRepository.delete(admission);
    }
}
