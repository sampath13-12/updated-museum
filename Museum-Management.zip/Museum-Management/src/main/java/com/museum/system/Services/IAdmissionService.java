package com.museum.system.Services;

import com.museum.system.Entities.Admission;

import java.util.List;
import java.util.Optional;

public interface IAdmissionService {
    public Admission createAdmission(Admission admission) ;

    public Optional<Admission> getAdmissionById(Long id) ;

    public List<Admission> getAllAdmissions() ;

    public Admission updateAdmission(Long id, Admission admissionDetails) ;

    public void deleteAdmission(Long id) ;
}
