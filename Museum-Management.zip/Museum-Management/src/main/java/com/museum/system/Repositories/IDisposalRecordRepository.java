package com.museum.system.Repositories;

import com.museum.system.Entities.DisposalRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IDisposalRecordRepository extends JpaRepository<DisposalRecord, Long> {
    void delete(Optional<DisposalRecord> disposalRecord);
}
