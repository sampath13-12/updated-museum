package com.museum.system.Services.Impl;

import com.museum.system.Entities.Location;
import com.museum.system.Repositories.ILocationRepository;
import com.museum.system.Services.ILocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LocationService implements ILocationService {

    @Autowired
    private ILocationRepository locationRepository;


    @Override
    public Location createLocation(Location location) {
        return locationRepository.save(location);
    }

    @Override
    public Optional<Location> getLocationById(Long id) {
        return locationRepository.findById(id);
    }

    @Override
    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

    @Override
    public Optional<Location> updateLocation(Long id, Location locationDetails) {
        Optional<Location> location = getLocationById(id);
        location.get().setName(locationDetails.getName());
        location.get().setParentLocation(locationDetails.getParentLocation());
        location.get().setSecurityLevel(locationDetails.getSecurityLevel());
        return Optional.of(locationRepository.save(locationDetails));
    }

    @Override
    public boolean deleteLocation(Long id) {
       Optional<Location> location = getLocationById(id);
       if(location.isPresent()){
           locationRepository.delete(location);
           return true;
       }
       return false;
    }
}
