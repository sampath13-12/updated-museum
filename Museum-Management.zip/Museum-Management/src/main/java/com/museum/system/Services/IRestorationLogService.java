package com.museum.system.Services;

import com.museum.system.Entities.RestorationLog;

import java.util.List;
import java.util.Optional;

public interface IRestorationLogService {

    public RestorationLog createRestorationLog(RestorationLog restorationLog) ;

    public Optional<RestorationLog> getRestorationLogById(Long id) ;

    public List<RestorationLog> getAllRestorationLogs() ;

    public RestorationLog updateRestorationLog(Long id, RestorationLog restorationDetails) ;

    public void deleteRestorationLog(Long id) ;
}
