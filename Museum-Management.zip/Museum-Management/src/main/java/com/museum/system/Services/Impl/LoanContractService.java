package com.museum.system.Services.Impl;

import com.museum.system.Entities.LoanContract;
import com.museum.system.Repositories.ILoanContractRepository;
import com.museum.system.Services.ILoanContractService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanContractService implements ILoanContractService {

    @Autowired
    private ILoanContractRepository loanContractRepository;


    @Override
    public LoanContract createLoanContract(LoanContract loanContract) {
        return loanContractRepository.save(loanContract);
    }

    @Override
    public Optional<LoanContract> getLoanContractById(Long id) {
        return loanContractRepository.findById(id);
    }

    @Override
    public List<LoanContract> getAllLoanContracts() {
        return loanContractRepository.findAll();
    }

    @Override
    public LoanContract updateLoanContract(Long id, LoanContract loanDetails) {
        Optional<LoanContract> loanContract = loanContractRepository.findById(id);
        if(loanContract.isPresent()){
            loanContract.get().setArtObjects(loanDetails.getArtObjects());
            loanContract.get().setStartDate(loanDetails.getStartDate());
            loanContract.get().setEndDate(loanDetails.getEndDate());
            loanContract.get().setInsurancePolicy(loanDetails.getInsurancePolicy());
            loanContract.get().setConstraints(loanDetails.getConstraints());
            loanContract.get().setContractDetails(loanDetails.getContractDetails());
        }
        return loanContractRepository.save(loanDetails);

    }

    @Override
    public boolean deleteLoanContract(Long id) {
        Optional<LoanContract> loanContract = loanContractRepository.findById(id);
        if(loanContract.isPresent()){
            loanContractRepository.delete(loanContract);
            return true;
        }
        return false;
    }
}
