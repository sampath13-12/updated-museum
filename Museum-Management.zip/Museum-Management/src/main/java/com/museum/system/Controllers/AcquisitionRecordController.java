package com.museum.system.Controllers;


import com.museum.system.Entities.AcquisitionRecord;
import com.museum.system.Services.Impl.AcquisitionRecordService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/acquisitions")
public class AcquisitionRecordController {

    @Autowired
    private AcquisitionRecordService acquisitionRecordService;

    // Create a new Acquisition Record
    @PostMapping
    public ResponseEntity<AcquisitionRecord> createAcquisitionRecord(@Valid @RequestBody AcquisitionRecord acquisitionRecord) {
        AcquisitionRecord createdRecord = acquisitionRecordService.createAcquisitionRecord(acquisitionRecord);
        return new ResponseEntity<>(createdRecord, HttpStatus.CREATED);
    }

    // Get an Acquisition Record by ID
    @GetMapping("/{id}")
    public ResponseEntity<Optional<AcquisitionRecord>> getAcquisitionRecordById(@PathVariable Long id) {
        Optional<AcquisitionRecord> record = acquisitionRecordService.getAcquisitionRecordById(id);
        return new ResponseEntity<>(record, HttpStatus.OK);
    }

    // Get all Acquisition Records
    @GetMapping
    public ResponseEntity<List<AcquisitionRecord>> getAllAcquisitionRecords() {
        List<AcquisitionRecord> records = acquisitionRecordService.getAllAcquisitionRecords();
        return new ResponseEntity<>(records, HttpStatus.OK);
    }

    // Update an Acquisition Record
    @PutMapping("/{id}")
    public ResponseEntity<AcquisitionRecord> updateAcquisitionRecord(@PathVariable Long id, @Valid @RequestBody AcquisitionRecord acquisitionDetails) {
        AcquisitionRecord updatedRecord = acquisitionRecordService.updateAcquisitionRecord(id, acquisitionDetails);
        return new ResponseEntity<>(updatedRecord, HttpStatus.OK);
    }

    // Delete an Acquisition Record
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAcquisitionRecord(@PathVariable Long id) {
        acquisitionRecordService.deleteAcquisitionRecord(id);
        return ResponseEntity.noContent().build();
    }
}
