package com.museum.system.Services.Impl;

import com.museum.system.Entities.Event;
import com.museum.system.Repositories.IEventRepository;
import com.museum.system.Services.IEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EventService implements IEventService {

    @Autowired
    private IEventRepository eventRepository;

    @Override
    public Event createEvent(Event event) {
        return eventRepository.save(event);
    }

    @Override
    public Optional<Event> getEventById(Long id) {
        return eventRepository.findById(id);
    }

    @Override
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    @Override
    public Event updateEvent(Long id, Event eventDetails) {
        try {
            Event event = getEventById(id).orElseThrow(() ->
                    new IllegalArgumentException("Event not found with id: " + id)
            );
            event.setName(eventDetails.getName());
            event.setEventDate(eventDetails.getEventDate());
            event.setAssociatedCollections(eventDetails.getAssociatedCollections());
            event.setDisplayAreas(eventDetails.getDisplayAreas());
            return eventRepository.save(event);
        } catch (IllegalArgumentException e) {
            System.err.println("Error updating event: " + e.getMessage());
            return null;
        }

    }

    @Override
    public void deleteEvent(Long id) {
        Optional<Event> event = getEventById(id);
        eventRepository.delete(event);
    }
}
