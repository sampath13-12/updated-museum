package com.museum.system.Repositories;

import com.museum.system.Entities.RestorationLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IRestorationLogRepository extends JpaRepository<RestorationLog, Long> {
    void delete(Optional<RestorationLog> restorationLog);
}
