package com.museum.system.Services;

import com.museum.system.Entities.Location;

import java.util.List;
import java.util.Optional;

public interface ILocationService {
    public Location createLocation(Location location);

    public Optional<Location> getLocationById(Long id) ;

    public List<Location> getAllLocations() ;

    public Optional<Location> updateLocation(Long id, Location locationDetails) ;

    public boolean deleteLocation(Long id) ;
}
