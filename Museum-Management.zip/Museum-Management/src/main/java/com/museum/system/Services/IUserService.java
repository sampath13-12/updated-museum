package com.museum.system.Services;

import com.museum.system.Entities.User;

import java.util.Collections;

public interface IUserService {

}
